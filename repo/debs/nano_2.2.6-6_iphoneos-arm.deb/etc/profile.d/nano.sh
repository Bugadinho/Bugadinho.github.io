export EDITOR=nano
